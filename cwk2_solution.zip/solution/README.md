# COMP2811 Coursework 2

## Sample Solution

Set up the build process with

    mkdir build && cd build && cmake ..

Build the application with

    make quaketool

or just `make` by itself.

Run the application with

    ./quaketool
